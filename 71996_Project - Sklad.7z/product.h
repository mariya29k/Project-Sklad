#pragma once

#include <iostream>
#include "date.h"
#include <string>
using namespace std;

class Product
{
    private:
    char* name;
    Date expiration_date;
    Date in_storage;
    char* manufacturer;
    double weight;
    int availability;
    int id;
    static int product_id;

    public:
    
    Product ();
    Product (const Product &other);
    const char* GetName () const;
    void SetName (const char* name_);
    void SetExpiration();
    Date GetExpiration();
    void SetinStorage();
    Date GetinStorage();
    const char* GetManufacturer() const;
    void SetManufacturer (const char* manufacturer_);
    double GetWeight () const;
    void SetWeight (double weight_);
    int GetAvailability () const;
    void SetAvailability (int availability_);
    int GetID () const;
    void print();
};