#include <iostream>
#include <vector>
#include "product.h"
#include "date.h"

using namespace std;

class Storage
{
    private:
    vector<Product> products;
    Date today;
    
    public:
    void addProduct(Product &product)
    {
        products.push_back(product);
    }

    //tr si napr id za products
    void removeProduct(Product &product)
    {   if(products.GetExpiration()==today.today_date())
        {
            products.erase(products.begin()+products.GetID());
        }
    }

    void print_products()
    {
        
    }
    
};