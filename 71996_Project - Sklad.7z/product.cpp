#include <iostream>
#include "date.h"
#include "date.cpp"
#include "product.h"
#include <cstring>

using namespace std;
    
    int Product:: product_id =1000;

    Product::Product ()
    {
        SetName("default");
        this->expiration_date = Date();
        this->in_storage = Date();
        SetManufacturer("default");
        this->weight = 0.0;
        this->availability = 0.0;
        this->id = product_id++;
        
    }


    Product:: Product (const Product &other)
    {
        SetName(other.name);
        expiration_date = other.expiration_date;
        in_storage = other.in_storage;
        SetManufacturer(other.manufacturer);
        weight = other.weight;
        availability = other.availability;
        id = other.id;
    }

    const char* Product::GetName () const //tova moje bi tr da e string
    {
        return this->name;
    }

    void Product::SetName (const char* name_) 
    {
        this->name=new char[strlen(name_)+1]; //tuk moje bi ne tr ima_
        strcpy(this->name, name_);
    }

//how to do that thingy here
    void Product::SetExpiration()
    {  
        cin>>expiration_date;
    }

    Date Product::GetExpiration()
    {
        return this->expiration_date;
    }

    void Product::SetinStorage()
    {  
        cin>>in_storage;
    }

    Date Product::GetinStorage()
    {
        return this->in_storage;
    }

    const char* Product::GetManufacturer() const
    {
        return this->manufacturer;
    }
    
    void Product::SetManufacturer (const char* manufacturer_)
    {
        this->manufacturer=new char[strlen(manufacturer_)+1]; //tuk moje bi ne tr ima_
        strcpy(this->manufacturer, manufacturer_);
    }

    double Product::GetWeight () const
    {
        return this->weight;
    }

    void Product::SetWeight (double weight_)
    {
        weight = weight_;
    }

    int Product::GetAvailability () const
    {
        return this->availability;
    }

    void Product::SetAvailability (int availability_)
    {
        availability = availability_;
    }

    int Product::GetID () const
    {
        return this->id;
    }


    /*const char *GetComment () const //this should be a sentence or a couple of sentences maybe idk
    {
        return comment;
    } //za comment dali mi tr set ili kak da se vuvejda inache hmmm
    }*/

